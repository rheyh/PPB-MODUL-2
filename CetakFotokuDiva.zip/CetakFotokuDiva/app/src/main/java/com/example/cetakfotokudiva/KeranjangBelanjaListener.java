package com.example.cetakfotokudiva;

public interface KeranjangBelanjaListener {
    void orderChanged();
}
